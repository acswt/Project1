package com.skillstorm.warehaus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WarehausApplication {

	public static void main(String[] args) {
		SpringApplication.run(WarehausApplication.class, args);
	}

}
