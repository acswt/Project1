package com.skillstorm.warehaus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehausApplicationTests {

	@Test
	void contextLoads() {
	}

}
